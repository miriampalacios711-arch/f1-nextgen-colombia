/* ============ CONFIGURACIÓN (edita aquí para actualizar la página) ============ */
var CONTACT = { email: "", instagram: "", tiktok: "", youtube: "" };
var DATA_DATE = "21 sep 2026";

var TEAMS = [
 {id:"mercedes",name:"Mercedes",color:"#27F4D2",engine:"Mercedes",pos:1,pts:503,wins:10,drivers:[{n:"Kimi Antonelli",c:"ITA",p:292,pos:1},{n:"George Russell",c:"GBR",p:211,pos:2}]},
 {id:"ferrari",name:"Ferrari",color:"#E8002D",engine:"Ferrari",pos:2,pts:358,drivers:[{n:"Lewis Hamilton",c:"GBR",p:191,pos:3},{n:"Charles Leclerc",c:"MON",p:167,pos:5}]},
 {id:"mclaren",name:"McLaren",color:"#FF8000",engine:"Mercedes",pos:3,pts:306,drivers:[{n:"Lando Norris",c:"GBR",p:186,pos:4,tag:"Campeón 2025"},{n:"Oscar Piastri",c:"AUS",p:120,pos:7}]},
 {id:"redbull",name:"Red Bull Racing",color:"#3671C6",engine:"Red Bull Ford",pos:4,pts:230,drivers:[{n:"Max Verstappen",c:"NED",p:145,pos:6},{n:"Isack Hadjar",c:"FRA",p:71,pos:8,tag:"Lesionado",red:1,note:"Lawson lo reemplaza desde Países Bajos"}]},
 {id:"rb",name:"Racing Bulls",color:"#6692FF",engine:"Red Bull Ford",pos:5,pts:77,drivers:[{n:"Liam Lawson",c:"NZL",p:59,pos:9,note:"Suplente en Red Bull"},{n:"Arvid Lindblad",c:"GBR",p:31,pos:11,tag:"Novato"},{n:"Yuki Tsunoda",c:"JPN",p:1,pos:20,tag:"Suplente",note:"Cubre a Lawson desde Países Bajos"}]},
 {id:"alpine",name:"Alpine",color:"#00A1E8",engine:"Mercedes",pos:6,pts:68,drivers:[{n:"Pierre Gasly",c:"FRA",p:41,pos:10},{n:"Franco Colapinto",c:"ARG",p:27,pos:12}]},
 {id:"haas",name:"Haas",color:"#B6BABD",engine:"Ferrari",pos:7,pts:21,drivers:[{n:"Oliver Bearman",c:"GBR",p:18,pos:13},{n:"Esteban Ocon",c:"FRA",p:3,pos:18}]},
 {id:"audi",name:"Audi",color:"#F50537",engine:"Audi",pos:8,pts:17,drivers:[{n:"Gabriel Bortoleto",c:"BRA",p:10,pos:14},{n:"Nico Hülkenberg",c:"GER",p:7,pos:15}],tag:"Debut 2026"},
 {id:"williams",name:"Williams",color:"#64C4FF",engine:"Mercedes",pos:9,pts:11,drivers:[{n:"Carlos Sainz",c:"ESP",p:6,pos:16},{n:"Alex Albon",c:"THA",p:5,pos:17}]},
 {id:"aston",name:"Aston Martin",color:"#229971",engine:"Honda",pos:10,pts:3,drivers:[{n:"Fernando Alonso",c:"ESP",p:3,pos:19},{n:"Lance Stroll",c:"CAN",p:0,pos:null}]},
 {id:"cadillac",name:"Cadillac",color:"#D9DCE1",engine:"Ferrari",pos:11,pts:0,drivers:[{n:"Sergio Pérez",c:"MEX",p:0,pos:null},{n:"Valtteri Bottas",c:"FIN",p:0,pos:null}],tag:"Debut 2026"}
];

var DONE = [
 [1,"Australia","Melbourne","Russell"],[2,"China","Shanghái","Antonelli"],[3,"Japón","Suzuka","Antonelli"],[4,"Miami","Miami","Antonelli"],
 [5,"Canadá","Montreal","Antonelli"],[6,"Mónaco","Montecarlo","Antonelli"],[7,"España","Barcelona","Hamilton"],[8,"Austria","Spielberg","Russell"],
 [9,"Gran Bretaña","Silverstone","Leclerc"],[10,"Bélgica","Spa-Francorchamps","Antonelli"],[11,"Hungría","Budapest","Norris"],[12,"Países Bajos","Zandvoort","Norris"],
 [13,"Italia","Monza","Antonelli"],[14,"España","Madring (Madrid)","Antonelli"]
];
var RACES = [
 {r:15,gp:"Azerbaiyán",circ:"Bakú",date:"2026-09-26",start:"2026-09-26T11:00:00Z",note:"Carrera en sábado"},
 {r:16,gp:"Bahréin en Malasia",circ:"Sepang",date:"2026-10-04",note:"Bahréin se disputa en Sepang"},
 {r:17,gp:"Singapur",circ:"Marina Bay",date:"2026-10-11"},
 {r:18,gp:"Estados Unidos",circ:"Austin",date:"2026-10-25"},
 {r:19,gp:"Ciudad de México",circ:"Hermanos Rodríguez",date:"2026-11-01"},
 {r:20,gp:"São Paulo",circ:"Interlagos",date:"2026-11-08"},
 {r:21,gp:"Las Vegas",circ:"Las Vegas Strip",date:"2026-11-21",note:"Carrera en sábado"},
 {r:22,gp:"Catar",circ:"Lusail",date:"2026-11-29"},
 {r:23,gp:"Abu Dabi",circ:"Yas Marina",date:"2026-12-06",note:"Final de temporada"}
];
var LAST = [["Kimi Antonelli","Mercedes"],["Max Verstappen","Red Bull"],["Lando Norris","McLaren"],["Charles Leclerc","Ferrari"],["George Russell","Mercedes"],["Liam Lawson","Red Bull"],["Franco Colapinto","Alpine"],["Oscar Piastri","McLaren"],["Arvid Lindblad","Racing Bulls"],["Nico Hülkenberg","Audi"]];

var NEWS = [
 {big:1,src:"Sky Sports F1 · 20 sep",t:"Rosberg: el mayor rival de Antonelli será su propia cabeza",d:"Antonelli lidera con 81 puntos de ventaja sobre Russell y podría ser el campeón más joven de la historia con 20 años. McLaren lleva mejoras a Bakú y Mercedes traerá un paquete importante a Malasia.",u:"https://www.skysports.com/f1/news/12040/13589366/kimi-antonelli-versus-his-mind-will-decide-2026-formula-1-title-race-says-nico-rosberg-ahead-of-azerbaijan-grand-prix"},
 {src:"Grande Prêmio · 21 sep",t:"Hadjar se juega su regreso en Bakú con un último test en simulador",d:"Red Bull decidirá tras la prueba y el visto bueno médico si el francés vuelve a correr o si Lawson tendrá una cuarta carrera seguida.",u:"https://grandepremio.com/en/f1/hadjar-faces-final-simulator-test-before-red-bull-decides-baku-return/"},
 {src:"Formula1.com · 21 sep",t:"Semana de carrera en Bakú: cinco historias para seguir",d:"Ronda 15 del campeonato, con el regreso posible de Hadjar y mejoras anunciadas por Williams.",u:"https://www.formula1.com/en/latest/article/its-race-week-5-storylines-were-excited-about-ahead-of-the-2026-azerbaijan-grand-prix.6l5UWWsSVJdtKOpR8KDSzZ"},
 {src:"Autosport · 15 sep",t:"Russell y Hamilton dan por perdidas sus opciones de título",d:"Tras 14 carreras, Hamilton está a 101 puntos del líder y Norris a 106. La amenaza real para Antonelli podría venir del desarrollo de Ferrari o McLaren.",u:"https://www.autosport.com/f1/news/russell-and-hamilton-concede-f1-2026-title-chances-as-antonelli-dominates/10856072/"},
 {src:"Yahoo Sports · 13 sep",t:"Antonelli gana el primer GP de España en Madrid",d:"Verstappen fue segundo y Norris tercero. Un virtual safety car en la vuelta 15 cambió la carrera.",u:"https://sports.yahoo.com/articles/f1-standings-2026-spanish-grand-122857052.html"},
 {src:"Formula1.com · 19 ago",t:"Lawson y Tsunoda cubren la baja de Hadjar",d:"Hadjar se fracturó una muñeca durante el receso de verano. Lawson pasó a Red Bull y Tsunoda volvió a correr con Racing Bulls, situación que se mantiene desde Países Bajos.",u:"https://www.formula1.com/en/latest/article/red-bull-confirm-hadjar-to-miss-dutch-grand-prix-as-lawson-steps-up-and-tsunoda-returns.3D3k7oc9dUwwEBZC7upjR1"},
 {src:"Formula1.com · 26 jul",t:"Malasia recibe el GP de Bahréin en Sepang, del 2 al 4 de octubre",d:"F1 vuelve a Malasia por primera vez desde 2017 tras la cancelación de las carreras de Bahréin y Arabia Saudita por el conflicto en Oriente Medio.",u:"https://www.formula1.com/en/latest/article/formula-1-and-fia-confirm-malaysia-will-join-2026-calendar-as-host-venue-for-bahrain-grand-prix.6lL7vjFEM2VVynRHvg1TCf"}
];

var TIMELINE = [
 {y:"1950",t:"Nace el Campeonato Mundial",d:"El 13 de mayo se corre en Silverstone la primera carrera puntuable. Giuseppe Farina, con Alfa Romeo, se convierte en el primer campeón del mundo."},
 {y:"1958",t:"Aparece el título de Constructores",d:"Se crea el campeonato de equipos, además del de pilotos. Vanwall se lleva el primero."},
 {y:"1977",t:"Llega el motor turbo",d:"Renault estrena el turbo en el GP de Gran Bretaña y abre una era de potencias enormes que dura hasta finales de los 80."},
 {y:"1988",t:"Senna contra Prost",d:"McLaren domina y la rivalidad entre Ayrton Senna y Alain Prost marca la época. Senna fue campeón en 1988, 1990 y 1991."},
 {y:"1994",t:"Un antes y un después en seguridad",d:"El fin de semana de Imola, en el que fallecieron Roland Ratzenberger y Ayrton Senna, impulsó una revolución de seguridad que llega hasta hoy con inventos como el HANS y el halo."},
 {y:"2001",t:"Montoya, el colombiano de la F1",d:"Juan Pablo Montoya debuta con Williams en 2001 y termina con 7 victorias en la categoría reina, corriendo también con McLaren. Es el gran referente de Colombia en la F1.",mont:1},
 {y:"2000–04",t:"Cinco títulos seguidos de Schumacher",d:"Michael Schumacher y Ferrari dominan con cinco campeonatos de pilotos consecutivos. Schumacher terminó con siete títulos, cifra que igualó después Lewis Hamilton."},
 {y:"2014",t:"La era híbrida",d:"Llegan los motores V6 turbo híbridos y Mercedes domina durante años la nueva era."},
 {y:"2019",t:"La F1 llega a Netflix",d:"El estreno de Drive to Survive acerca la F1 a millones de personas nuevas y rejuvenece a la afición."},
 {y:"2021",t:"Un final de infarto",d:"Max Verstappen supera a Lewis Hamilton en la última vuelta del último Gran Premio en Abu Dabi y gana su primer título."},
 {y:"2025",t:"Norris, campeón",d:"Lando Norris gana su primer campeonato por solo dos puntos sobre Verstappen."},
 {y:"2026",t:"Reglamento nuevo y dos equipos más",d:"Motores con mucha más energía eléctrica, aerodinámica activa, debut de Audi y Cadillac. Kimi Antonelli, de 20 años, lidera el campeonato."}
];

var CIRCUITS = [
 {n:"Mónaco",k:"Montecarlo · Calle",d:"3,337 km entre barreras. Adelantar es casi imposible, así que clasificar bien lo es casi todo.",p:"M8 44 L14 26 L30 22 L36 8 L54 6 L60 22 L84 26 L86 40 L60 48 L36 40 Z"},
 {n:"Spa-Francorchamps",k:"Bélgica",d:"7,004 km, la pista más larga del calendario. Eau Rouge y un clima que puede llover solo en una parte.",p:"M6 46 L20 30 L14 14 L40 8 L52 22 L70 18 L88 34 L64 50 Z"},
 {n:"Monza",k:"Italia · Templo de la velocidad",d:"Rectas larguísimas y poca carga aerodinámica. Este año la ganó Antonelli, en casa.",p:"M8 40 L8 14 L48 10 L88 16 L82 34 L54 30 L44 46 Z"},
 {n:"Suzuka",k:"Japón",d:"El único circuito en forma de ocho, con un cruce a distinto nivel y curvas en S que los pilotos adoran.",p:"M12 38 Q6 18 26 16 Q44 16 46 28 Q52 44 70 40 Q88 34 80 20 Q70 8 50 22 Q34 36 12 38 Z"},
 {n:"Silverstone",k:"Reino Unido",d:"Sede de la primera carrera del campeonato, en 1950. En 2026 ganó Leclerc.",p:"M10 34 L22 14 L46 10 L70 16 L88 30 L74 46 L40 44 Z"},
 {n:"Interlagos",k:"São Paulo · Brasil",d:"Sentido antihorario, subidas y bajadas. Un clásico muy querido por la afición latina; se corre el 8 de noviembre.",p:"M10 40 L20 18 L46 12 L60 24 L84 20 L86 42 L50 48 Z"},
 {n:"Bakú",k:"Azerbaiyán · Calle",d:"Rectas rapidísimas y un tramo estrechísimo junto al casco antiguo. Es la próxima parada, el sábado 26 de septiembre.",p:"M8 46 L8 16 L36 16 L36 30 L58 30 L58 10 L88 10 L88 46 Z"},
 {n:"Madring",k:"Madrid · Estreno 2026",d:"Circuito nuevo en Madrid, estrenado en septiembre de 2026 con victoria de Antonelli.",p:"M10 38 L22 12 L50 8 L64 20 L88 24 L82 44 L48 48 Z"}
];

var FLAGS = [
 {c:"#22c55e",n:"Verde",d:"Pista libre; se puede correr."},
 {c:"#FFC300",n:"Amarilla",d:"Peligro: reduce y no adelantes."},
 {c:"#E10600",n:"Roja",d:"Sesión detenida."},
 {c:"#2f80ed",n:"Azul",d:"Deja pasar: viene un coche más rápido."},
 {c:"#ffffff",n:"Blanca",d:"Hay un coche lento en la pista."},
 {c:"#000000",n:"Negra",d:"Sanción: el piloto debe volver a boxes."},
 {c:"repeating-conic-gradient(#fff 0 25%,#000 0 50%) 0 0/12px 12px",n:"A cuadros",d:"Fin de la carrera."}
];
var GLOSS = [
 ["Pole","Salir primero en la parrilla, tras hacer la vuelta más rápida en clasificación."],
 ["Boxes","Zona donde los equipos cambian neumáticos y reparan el coche."],
 ["Undercut","Parar antes que un rival para salir con neumáticos nuevos y pasarlo cuando él pare."],
 ["Safety Car","Coche de seguridad que neutraliza la carrera tras un accidente. Todos van en fila y no se adelanta."],
 ["Virtual Safety Car (VSC)","Todos deben reducir la velocidad a un límite marcado, sin salir el coche de seguridad."],
 ["Parrilla","Posiciones de salida de los coches, ordenadas según la clasificación."],
 ["Degradación","Pérdida de agarre de los neumáticos a medida que se desgastan."],
 ["Neumáticos","Los compuestos van de más blandos (rápidos, duran menos) a más duros (más lentos, duran más)."],
 ["Vuelta rápida","La vuelta más veloz de la carrera. Ya no da punto extra desde 2025."],
 ["Aire sucio","La turbulencia del coche de adelante que le quita agarre al que lo sigue."],
 ["Parc fermé","Régimen que limita los cambios en los coches entre la clasificación y la carrera."],
 ["Halo","Estructura de titanio sobre el habitáculo que protege la cabeza del piloto; obligatorio desde 2018."],
 ["Sprint","Carrera corta de sábado en algunos fines de semana, con puntos propios."],
 ["Podio","Los tres primeros de la carrera."]
];
var QUIZ = [
 {q:"¿Cuántos puntos gana el ganador de un Gran Premio?",o:["20","25","30","18"],a:1,e:"El ganador suma 25. Luego 18, 15, 12, 10, 8, 6, 4, 2 y 1 para los diez primeros."},
 {q:"¿Qué significa una bandera amarilla?",o:["Fin de la carrera","Sanción","Peligro: reduce y no adelantes","Deja pasar al coche de atrás"],a:2,e:"La amarilla avisa de un peligro en pista. Está prohibido adelantar en esa zona."},
 {q:"¿Qué piloto colombiano ganó 7 Grandes Premios?",o:["Juan Pablo Montoya","Roberto Guerrero","Sebastián Saavedra","Tatiana Calderón"],a:0,e:"Juan Pablo Montoya ganó siete carreras corriendo para Williams y McLaren."},
 {q:"¿Qué circuito tiene forma de ocho?",o:["Monza","Suzuka","Interlagos","Spa"],a:1,e:"Suzuka, en Japón, es el único con un cruce a distinto nivel."},
 {q:"¿Qué novedad tienen los coches de 2026?",o:["Vuelven los motores V10","Se prohíben las paradas","Aerodinámica activa y más potencia eléctrica","Solo hay 10 equipos"],a:2,e:"Los alerones móviles y un motor mucho más eléctrico son la gran novedad, con 11 equipos."},
 {q:"Tras 14 carreras, ¿quién lidera el campeonato de 2026?",o:["George Russell","Lewis Hamilton","Lando Norris","Kimi Antonelli"],a:3,e:"Antonelli suma 292 puntos, 81 más que Russell (dato al 21 de septiembre de 2026)."}
];

/* ============ utilidades ============ */
function $(s,r){return (r||document).querySelector(s)}
function $$(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function toast(m){var t=$("#toast");t.textContent=m;t.classList.add("show");clearTimeout(toast._t);toast._t=setTimeout(function(){t.classList.remove("show")},2800)}
var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ============ menú ============ */
(function(){
  var b=$("#burger"),m=$("#menu");
  b.addEventListener("click",function(){var o=m.classList.toggle("open");b.setAttribute("aria-expanded",o)});
  $$("a",m).forEach(function(a){a.addEventListener("click",function(){m.classList.remove("open");b.setAttribute("aria-expanded","false")})});
  var links=$$("a",m), secs=links.map(function(a){return $(a.getAttribute("href"))});
  if("IntersectionObserver" in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){links.forEach(function(l){l.classList.toggle("on",l.getAttribute("href")==="#"+e.target.id)})}})},{rootMargin:"-45% 0px -50% 0px"});
    secs.forEach(function(s){if(s)io.observe(s)});
  }
})();

/* ============ líneas de velocidad + luces de salida del hero ============ */
(function(){
  var sp=$("#speed");
  for(var i=0;i<14;i++){var l=document.createElement("i");l.style.top=(6+Math.random()*88)+"%";l.style.animationDuration=(1.6+Math.random()*2.4)+"s";l.style.animationDelay=(Math.random()*3)+"s";l.style.width=(18+Math.random()*30)+"%";sp.appendChild(l)}
  var lights=$$("#lights i");
  function seq(){
    lights.forEach(function(x){x.classList.remove("on")});
    lights.forEach(function(x,i){setTimeout(function(){x.classList.add("on")},500+i*550)});
    setTimeout(function(){lights.forEach(function(x){x.classList.remove("on")})},500+5*550+900);
  }
  if(reduce){lights.forEach(function(x){x.classList.add("on")})}else{seq();setInterval(seq,9000)}
})();

/* ============ cuenta regresiva y calendario ============ */
function nextRace(){
  var now=Date.now();
  for(var i=0;i<RACES.length;i++){
    var end=new Date(RACES[i].date+"T23:59:59Z").getTime()+12*3600*1000;
    if(now<end)return RACES[i];
  }
  return null;
}
function fmtBogota(iso){
  try{return new Intl.DateTimeFormat("es-CO",{weekday:"long",day:"numeric",month:"long",hour:"numeric",minute:"2-digit",timeZone:"America/Bogota"}).format(new Date(iso))}catch(e){return ""}
}
function fmtDate(d){
  try{return new Intl.DateTimeFormat("es-CO",{weekday:"long",day:"numeric",month:"long",timeZone:"UTC"}).format(new Date(d+"T12:00:00Z"))}catch(e){return d}
}
function fmtShort(d){
  try{return new Intl.DateTimeFormat("es-CO",{day:"numeric",month:"short",timeZone:"UTC"}).format(new Date(d+"T12:00:00Z"))}catch(e){return d}
}
function pad2(n){return n<10?"0"+n:""+n}
(function(){
  var nr=nextRace();
  var title=$("#nextTitle"),sub=$("#nextSub"),note=$("#cdNote"),kick=$("#nextKicker");
  if(!nr){kick.textContent="Temporada";title.textContent="Temporada 2026 finalizada";sub.textContent="Gracias por acompañarnos";return}
  title.textContent="GP de "+nr.gp;
  sub.textContent=nr.circ+" · ronda "+nr.r+(nr.note?" · "+nr.note:"");
  function tick(){
    var now=Date.now(),target=nr.start?new Date(nr.start).getTime():null;
    if(target&&now<target){
      var s=Math.floor((target-now)/1000);
      $("#cdD").textContent=pad2(Math.floor(s/86400));$("#cdH").textContent=pad2(Math.floor(s%86400/3600));$("#cdM").textContent=pad2(Math.floor(s%3600/60));$("#cdS").textContent=pad2(s%60);
      note.textContent="Carrera: "+fmtBogota(nr.start)+" (hora de Colombia)";
    }else if(target){
      $("#cdD").textContent=$("#cdH").textContent=$("#cdM").textContent=$("#cdS").textContent="00";
      note.textContent="¡Fin de semana de carrera en curso o recién terminado!";
    }else{
      var days=Math.ceil((new Date(nr.date+"T00:00:00Z").getTime()-now)/86400000);
      $("#cdD").textContent=pad2(Math.max(days,0));$("#cdH").textContent=$("#cdM").textContent=$("#cdS").textContent="--";
      note.textContent="Carrera el "+fmtDate(nr.date)+".";
    }
  }
  tick();setInterval(tick,1000);
})();
(function(){
  var ul=$("#cal"),nr=nextRace(),html="";
  DONE.forEach(function(r){html+='<li class="done"><span class="rn">'+r[0]+'</span><span class="gp"><b>'+esc(r[1])+'</b><small>'+esc(r[2])+'</small></span><span class="who">'+esc(r[3])+'<small>ganó</small></span></li>'});
  RACES.forEach(function(r){
    var isNext=nr&&nr.r===r.r;
    var end=new Date(r.date+"T23:59:59Z").getTime()+12*3600*1000, past=Date.now()>=end;
    var right=past?'<span class="who">Terminada<small>resultado por actualizar</small></span>':(isNext?'<span class="who">Próxima<small>'+esc(fmtDate(r.date))+'</small></span>':'<span class="who" style="color:var(--muted)">'+esc(fmtShort(r.date))+'</span>');
    html+='<li class="'+(isNext?"next":"")+'"><span class="rn">'+r.r+'</span><span class="gp"><b>'+esc(r.gp)+'</b><small>'+esc(r.circ)+(r.note?" · "+esc(r.note):"")+'</small></span>'+right+'</li>';
  });
  ul.innerHTML=html;
  var nx=$(".next",ul); if(nx&&ul.scrollTo){ul.scrollTop=Math.max(nx.offsetTop-60,0)}
  var completed=DONE.length; $("#pillRounds").textContent=completed+" de 23";
  $("#podium").innerHTML=LAST.map(function(p,i){return '<li><span class="ps">'+(i+1)+'</span><span>'+esc(p[0])+'</span><small>'+esc(p[1])+'</small></li>'}).join("");
})();

/* ============ noticias ============ */
$("#news").innerHTML=NEWS.map(function(n){
  return '<a class="news rv'+(n.big?" big":"")+'" href="'+esc(n.u)+'" target="_blank" rel="noopener noreferrer"><span class="src">'+esc(n.src)+'</span><h3>'+esc(n.t)+'</h3><p>'+esc(n.d)+'</p><span class="go">Leer en la fuente</span></a>';
}).join("");

/* ============ historia y circuitos ============ */
$("#timeline").innerHTML=TIMELINE.map(function(t){
  return '<div class="tl rv'+(t.mont?" mont":"")+'"><div class="card">'+(t.mont?'<span class="tag">Orgullo colombiano</span>':'')+'<div class="yr">'+esc(t.y)+'</div><h3>'+esc(t.t)+'</h3><p>'+esc(t.d)+'</p></div></div>';
}).join("");
$("#circuits").innerHTML=CIRCUITS.map(function(c){
  return '<div class="circ rv"><svg viewBox="0 0 96 56" aria-hidden="true"><path d="'+c.p+'"/></svg><small>'+esc(c.k)+'</small><h4>'+esc(c.n)+'</h4><p>'+esc(c.d)+'</p></div>';
}).join("");

/* ============ parrilla ============ */
var view="equipos", engineFilter="Todos";
function teamOf(id){return TEAMS.filter(function(t){return t.id===id})[0]}
function renderChips(){
  var engines=["Todos"].concat(TEAMS.map(function(t){return t.engine}).filter(function(v,i,a){return a.indexOf(v)===i}));
  var box=$("#chips");
  box.style.display=view==="equipos"?"flex":"none";
  box.innerHTML=engines.map(function(e){return '<button class="chip" aria-pressed="'+(e===engineFilter)+'" data-e="'+esc(e)+'">'+(e==="Todos"?"Todos los equipos":"Motor "+esc(e))+'</button>'}).join("");
  $$(".chip",box).forEach(function(b){b.addEventListener("click",function(){engineFilter=b.getAttribute("data-e");render()})});
}
function bars(){
  requestAnimationFrame(function(){requestAnimationFrame(function(){$$(".fill i").forEach(function(i){i.style.width=i.getAttribute("data-w")+"%"})})});
}
function render(){
  renderChips();
  var v=$("#view"),note=$("#viewNote"),h="";
  if(view==="equipos"){
    var list=TEAMS.filter(function(t){return engineFilter==="Todos"||t.engine===engineFilter});
    h='<div class="teams">'+list.map(function(t){
      return '<article class="team rv in" style="--tc:'+t.color+'"><div class="bar"></div><div class="hd"><div><h3>'+esc(t.name)+(t.tag?'<span class="badge">'+esc(t.tag)+'</span>':'')+'</h3></div><div class="pos">P'+t.pos+'</div></div><div class="meta">Motor <b>'+esc(t.engine)+'</b></div>'+
      t.drivers.map(function(d){return '<div class="drv"><div class="nm">'+esc(d.n)+(d.tag?'<span class="badge'+(d.red?" red":"")+'">'+esc(d.tag)+'</span>':'')+'<small>'+esc(d.c)+(d.note?" · "+esc(d.note):"")+'</small></div><div class="pt">'+d.p+' <small>PTS</small></div></div>'}).join("")+
      '<div class="total" style="margin-top:12px">Total del equipo: <b style="color:#fff">'+t.pts+' pts</b></div></article>';
    }).join("")+'</div>';
    note.textContent="Los puntos de cada piloto son los del campeonato de pilotos; el total del equipo cuenta también los que sumaron los suplentes.";
  }else if(view==="pilotos"){
    var all=[];TEAMS.forEach(function(t){t.drivers.forEach(function(d){all.push({n:d.n,c:d.c,p:d.p,pos:d.pos,t:t})})});
    all.sort(function(a,b){if(b.p!==a.p)return b.p-a.p;return (a.pos||99)-(b.pos||99)});
    var max=all[0].p;
    h='<div class="tablewrap"><table class="st"><thead><tr><th>Pos</th><th>Piloto</th><th>Equipo</th><th>Progreso</th><th style="text-align:right">Pts</th></tr></thead><tbody>'+all.map(function(d){
      return '<tr style="--tc:'+d.t.color+'"><td class="n">'+(d.pos||"–")+'</td><td><b>'+esc(d.n)+'</b> <span style="color:var(--faint);font-size:12px">'+esc(d.c)+'</span></td><td><span class="dot"></span>'+esc(d.t.name)+'</td><td><div class="fill"><i data-w="'+(d.p/max*100).toFixed(1)+'"></i></div></td><td class="p">'+d.p+'</td></tr>';
    }).join("")+'</tbody></table></div>';
    note.textContent="Clasificación de pilotos tras la ronda 14. Quedan 233 puntos en juego (9 carreras y 1 sprint).";
  }else{
    var cs=TEAMS.slice().sort(function(a,b){return a.pos-b.pos}),cm=cs[0].pts;
    h='<div class="tablewrap"><table class="st"><thead><tr><th>Pos</th><th>Equipo</th><th>Motor</th><th>Progreso</th><th style="text-align:right">Pts</th></tr></thead><tbody>'+cs.map(function(t){
      return '<tr style="--tc:'+t.color+'"><td class="n">'+t.pos+'</td><td><span class="dot"></span><b>'+esc(t.name)+'</b></td><td style="color:var(--muted)">'+esc(t.engine)+'</td><td><div class="fill"><i data-w="'+(t.pts/cm*100).toFixed(1)+'"></i></div></td><td class="p">'+t.pts+'</td></tr>';
    }).join("")+'</tbody></table></div>';
    note.textContent="Clasificación de constructores tras la ronda 14. Mercedes lleva 10 victorias y 145 puntos de ventaja sobre Ferrari.";
  }
  v.innerHTML=h;
  bars();
}
$$(".tab").forEach(function(b){b.addEventListener("click",function(){
  view=b.getAttribute("data-view");
  $$(".tab").forEach(function(x){x.setAttribute("aria-selected",x===b)});
  render();
})});
render();

/* ============ aprende ============ */
$("#pts").innerHTML=[25,18,15,12,10,8,6,4,2,1].map(function(p,i){return '<span>'+p+'<small>P'+(i+1)+'</small></span>'}).join("");
$("#flags").innerHTML=FLAGS.map(function(f){return '<div class="flag"><i style="background:'+f.c+'"></i><span><b>'+esc(f.n)+'</b>'+esc(f.d)+'</span></div>'}).join("");
function renderGloss(q){
  q=(q||"").toLowerCase().trim();
  var items=GLOSS.filter(function(g){return !q||g[0].toLowerCase().indexOf(q)>-1||g[1].toLowerCase().indexOf(q)>-1});
  $("#gloss").innerHTML=items.length?items.map(function(g){return '<div><b>'+esc(g[0])+'</b>'+esc(g[1])+'</div>'}).join(""):'<div>No encontramos ese término todavía.</div>';
}
renderGloss();$("#gsearch").addEventListener("input",function(e){renderGloss(e.target.value)});

/* quiz */
(function(){
  var i=0,score=0,box=$("#quiz"),locked=false;
  function show(){
    locked=false;
    if(i>=QUIZ.length){
      var msg=score>=5?"¡Ya eres un experto de la parrilla!":score>=3?"¡Muy bien! Vas por buen camino.":"Buen inicio: repasa el glosario y vuelve a intentarlo.";
      box.innerHTML='<h3>Quiz F1</h3><div class="q-count">Resultado final</div><div class="q-text">Acertaste '+score+' de '+QUIZ.length+'. '+msg+'</div><button class="btn mini" id="qr" type="button"><span>Reintentar</span></button>';
      $("#qr").addEventListener("click",function(){i=0;score=0;show()});return;
    }
    var q=QUIZ[i];
    box.innerHTML='<h3>Quiz F1</h3><div class="q-count">Pregunta '+(i+1)+' de '+QUIZ.length+'</div><div class="q-text">'+esc(q.q)+'</div><div class="opts">'+q.o.map(function(o,k){return '<button class="opt" type="button" data-k="'+k+'">'+esc(o)+'</button>'}).join("")+'</div><div class="q-exp" id="qe"></div><div class="q-foot"><span class="q-count">Puntos: '+score+'</span><button class="btn mini" id="qn" type="button" style="visibility:hidden"><span>'+(i===QUIZ.length-1?"Ver resultado":"Siguiente")+'</span></button></div>';
    $$(".opt",box).forEach(function(b){b.addEventListener("click",function(){
      if(locked)return;locked=true;
      var k=+b.getAttribute("data-k"),ok=k===q.a;if(ok)score++;
      $$(".opt",box).forEach(function(x,j){x.disabled=true;if(j===q.a)x.classList.add("ok");else if(x===b)x.classList.add("no")});
      $("#qe").textContent=(ok?"¡Correcto! ":"No exactamente. ")+q.e;
      var n=$("#qn");n.style.visibility="visible";n.addEventListener("click",function(){i++;show()});
    })});
  }
  show();
})();

/* test de reflejos */
(function(){
  var lights=$$("#rlights i"),pad=$("#pad"),res=$("#rres"),state="idle",timers=[],t0=0,best=null;
  try{var b=localStorage.getItem("f1ng_best");if(b)best=+b}catch(e){}
  function clear(){timers.forEach(clearTimeout);timers=[]}
  function off(){lights.forEach(function(l){l.classList.remove("on")})}
  function reset(){pad.className="pad";}
  function start(){
    clear();off();reset();state="seq";res.innerHTML=best?'Tu mejor tiempo: <b>'+best+' ms</b>':"";
    pad.textContent="Espera…";
    lights.forEach(function(l,i){timers.push(setTimeout(function(){l.classList.add("on")},400+i*700))});
    var wait=400+4*700+800+Math.random()*2400;
    timers.push(setTimeout(function(){off();state="go";pad.classList.add("go");pad.textContent="¡YA!";t0=performance.now()},wait));
  }
  pad.addEventListener("click",function(){
    if(state==="idle"){start();return}
    if(state==="seq"){clear();state="idle";off();pad.className="pad early";pad.textContent="Salida en falso. Toca para reintentar";res.textContent="¡Te adelantaste! Espera a que se apaguen todas las luces.";return}
    if(state==="go"){
      var ms=Math.round(performance.now()-t0);state="idle";
      if(!best||ms<best){best=ms;try{localStorage.setItem("f1ng_best",String(ms))}catch(e){}}
      var rank=ms<200?"¡Nivel piloto de F1!":ms<300?"Muy buenos reflejos.":ms<450?"Bien, ¡sigue practicando!":"Todavía puedes mejorar.";
      pad.className="pad";pad.textContent="Toca para intentar de nuevo";
      res.innerHTML='Tu tiempo: <b>'+ms+' ms</b> · '+rank+(best?' · Mejor: <b>'+best+' ms</b>':'');
    }
  });
  if(best)res.innerHTML='Tu mejor tiempo: <b>'+best+' ms</b>';
})();

/* ============ comunidad y contacto ============ */
(function(){
  var inner=$("#contactInner"),ch=$("#channels"),chh="";
  if(CONTACT.email){
    inner.innerHTML='<p style="color:var(--muted);font-size:15px;margin-bottom:14px">Cuéntanos qué te gustaría ver en la página o comparte una idea.</p><form id="cform" novalidate><div class="field"><label for="cn">Tu nombre</label><input id="cn" autocomplete="name"></div><div class="field"><label for="cm">Mensaje</label><textarea id="cm"></textarea></div><button class="btn" type="submit"><span>Enviar por correo</span></button></form>';
    $("#cform").addEventListener("submit",function(e){e.preventDefault();var n=$("#cn").value.trim(),m=$("#cm").value.trim();if(!m){toast("Escribe un mensaje primero");return}
      location.href="mailto:"+CONTACT.email+"?subject="+encodeURIComponent("F1 NextGen Colombia · mensaje de "+(n||"un aficionado"))+"&body="+encodeURIComponent(m)});
  }else{
    inner.innerHTML='<p style="color:var(--muted);font-size:15px">Muy pronto abriremos los canales de contacto para que compartas ideas, preguntas y sugerencias. Mientras tanto, ayúdanos a crecer compartiendo la página con otros aficionados.</p>';
  }
  if(CONTACT.instagram)chh+='<a class="btn ghost mini" href="'+esc(CONTACT.instagram)+'" target="_blank" rel="noopener noreferrer"><span>Instagram</span></a>';
  if(CONTACT.tiktok)chh+='<a class="btn ghost mini" href="'+esc(CONTACT.tiktok)+'" target="_blank" rel="noopener noreferrer"><span>TikTok</span></a>';
  if(CONTACT.youtube)chh+='<a class="btn ghost mini" href="'+esc(CONTACT.youtube)+'" target="_blank" rel="noopener noreferrer"><span>YouTube</span></a>';
  ch.innerHTML=chh;
  $("#share").addEventListener("click",function(){
    var data={title:"F1 NextGen Colombia",text:"La próxima generación acelera aquí. Descubre la Fórmula 1 con F1 NextGen Colombia.",url:location.href};
    if(navigator.share){navigator.share(data).catch(function(){})}
    else if(navigator.clipboard){navigator.clipboard.writeText(location.href).then(function(){toast("Enlace copiado")},function(){toast("Copia el enlace desde la barra del navegador")})}
    else toast("Copia el enlace desde la barra del navegador");
  });
})();

/* ============ animaciones al hacer scroll ============ */
(function(){
  var els=$$(".rv");
  if(!("IntersectionObserver" in window)||reduce){els.forEach(function(e){e.classList.add("in")});animateCounts(true);return}
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
  els.forEach(function(e){io.observe(e)});
  animateCounts(false);
})();
function animateCounts(skip){
  $$(".cnt").forEach(function(el){
    var to=+el.getAttribute("data-to");if(skip){el.textContent=to;return}
    var t0=null;function step(ts){if(!t0)t0=ts;var p=Math.min((ts-t0)/1300,1),e=1-Math.pow(1-p,3);el.textContent=Math.round(to*e);if(p<1)requestAnimationFrame(step)}
    requestAnimationFrame(step);
  });
}